﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Dog
    {
        static public int count = 0;
        public readonly string name;
        //Each class can have its own associated destructor which does not take any parameters and does not need calling.
        //It is invoked when the object is destroyed
        ~Dog()
        {
            count--;
            //code
            Console.WriteLine(count);

        } // is an example of destructor
        //Static means that the memebers will belong to the class instead of individual object
        //so a static method belongs to the class, whereas a non-static method is individual, same for the variables
        public Dog(string name)
        {
            count++;
            this.name = name;
            Console.WriteLine("At count {0} is {1}", count, this.name);

        }
    }
    class Box
    {
        public int height;
        public int width;
        public Box()
        {
            height = 0;
            width = 0;
        }
        public Box(int height, int width)
        {
            this.height = height;
            this.width = width;
        }
        public static Box operator+ (Box a, Box b)
        {
            int h = a.height + b.height;
            int w = a.width + b.width;
            Box res = new Box(h, w);
            return res;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //array declaration
            int[] myArray = { 10, 20, 30, 40, 2, 4, 3, 233, 213, 25, 13, 23, 1 };
            int[] myArray2 = new int[100]; //will hold 100 elements
            //we can access each element in the array using a foreach loop
            foreach(int k in myArray)
            {
                //Console.WriteLine(k);
            }
            //Just like Single Dimension array, we got multidimension array
            int[,,] myMultiArray = new int[200,200,200]; // this is a 3 dimensional array
            //first element is a[0][0], the one below it is a[0][1] and the one on its right is a[1][0]
            //now let us consider the concept of jagged array
            //jagged array is an array whose elements are arrays, so basically it is an array of arrays.
            //Imagine, if you declare a single dimensional array whose each element is an array in itself
            //This is effectiely different from multidimensional array, because multidimensional arrays have fixed size
            //each individual array in jagged array can have its own size.
            int[][] jaggedArr = new int[][]
            {
                new int[]{1,8,2,3,4,5},
                new int[]{2,45,3},
                new int[]{3,5,2,1,3,4,231,235,577,42,13}

            };
            Console.WriteLine(myArray.Length); // how many elements in 1st dimension, second dimension, etc.
            Console.WriteLine(myArray.Rank); // how many dimensions?
            myArray.Sum(); //sum of the array elements
            myArray.Max(); // max of all elements
            myArray.Min(); // min of all elements
                           // Strings can be considered as a array of characters.
                           /* There are various string functions that can be used.
                            * if string a = "Hello"
                            * a = a.insert(0, "How do you say ") will give a = How do you say Hello
                            * a = a.replace("How do you", "When do you") will give a = When do you say Hello
                            * a = a.delete(4) will give a = How
                            * b = a.Contains("How") will return true or false
                            * a = a.substring(2) will return a = "o"
                            */
            Dog d1 = new Dog("Toby");
            Dog d2 = new Dog("Ariel");
            Dog d3 = new Dog("Lucifer");
            Console.WriteLine(Dog.count);
            //  d1.name = "Muriel"; <-- gives an error CS0191
            // now let us use the keyword "this"
            /* this is used to refer to the current instance of the class, basically refer 
             * to the current object of that class.
             */
            // basically this is used to differentiate the class members from all the other data of a method.

            /* now to the readonly modifier. Basically, if you want a member of a class to 
             * not be modified after construction, then you declare it as a readonly.
             * The readonly modifier can be modified only when declared or when called by a constructor.
             * This is different from 'const' keyword, because..
             * const needs initialization when declared, and read only can be declared without initialization
             * also, readonly value can be changed in a constructor
             * read only can be a value that can arise due to a result of a calculation.
             */

            // Now let us understand what indexers are!
            /* Indexer is basically a facility that allows us to index objects like an array.
             * It is declared like a property, except that the accessors require an index
             * get : will recieve the index of object created
             * set : will set the value to the corresponding array
             */
            /* Now let us understand operator overloading
             */
            Box b1 = new Box(4, 5);
            Box b2 = new Box(5, 7);
            Box b3 = b1 + b2;
            Console.WriteLine("{0}, {1}", b3.height, b3.width);

        }
    }
}
