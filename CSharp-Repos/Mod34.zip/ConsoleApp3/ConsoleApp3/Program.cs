﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* So what exactly is a namespace?
 * Namespace is used as a set of relatable objects
 * It can be used to organize related code elements
 * We have to use 'using' keyword to initiate the given namespace
 */
namespace ConsoleApp3
{
    class Animal
    {
        
        protected string Name
        {
            get;
            set;
        }
        public int Legs
        {
            get;
            set;
        }
        public int Age
        {
            get;
            set;
        }
        public string IfMammal(bool isMammal)
        {
            string answer;
            if (isMammal == true)
            {
                answer = "WARM BLOODED ANIMAL";
                return answer;
            }
            else
            {
                answer = "COLD BLOODED INSECTTT!!!";
                return answer;
            }
        }
    }
    class Dog : Animal //Dog derives properties from Animal
    {
        /* Now all public members of class Animal become public members of Dog.
         * So we can access Legs from Dog constructor
         */
        public Dog(string name)
        {
            this.Name = name;
            Legs = 4;
        }
        public Dog()
        {
            Legs = 4;
        }
        public void Bark()
        {
            Console.WriteLine("Woof!");
        }
        public static void NameChange(Dog d1, string newName)
        {
            Console.WriteLine("{0}", d1.Name);
            d1.Name = newName;
            Console.WriteLine("{0}", d1.Name);
        }
        
    }
    class Shape
    {
        public virtual void Draw()
        {
            Console.WriteLine("Draw Shape");
        }
    }
    class Circle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("Draw Circle");
        }
    }
    class Rectangle : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("Draw Rectangle");
            base.Draw();
        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            string isMammal;
            /* Inheritance is a useful tool.
            * It allows you to get properties of one class and use it on another class
            * The class from where you take the properties (whose properties are
            * inherited) is called the base class. The class who inherits the properties
            * from the base class is called as the Derived class.
            * For Example,
            * Mammals can be a base class with properties like body hair, blood type, etc.
            * Humans, Dogs, Cats can be derived classes with individual properties that seperate them.
            */
            Dog d1 = new Dog("awesome");
            Console.WriteLine("{0}", d1.Legs);
            d1.Bark();
            
            isMammal = d1.IfMammal(true);
            Console.WriteLine("{0}", isMammal);
            Dog.NameChange(d1, "cute");

            /* Another protection level is 'sealed'
             * Here, if a class is sealed, it cannot be inherited from any other class
             */

            /* One must note that with inheritance, while the base methods and variables can be inherited
             * the base constructors and destructors are not inherited. Thus we have to define our constructors
             * again with respect to the inheriting class.
             * 
             * The order of creation and destruction of object (calling of constructor and destructor) is as follows
             * i)   base constructor
             * ii)  derived constructor
             * iii) derived destructor
             * iv)  base destructor
             */

            /* Another interesting OOPs feature is polymorphism
             * Polymorphism basically allows us to invoke a heirarchy of class and allow them to be
             * related through inheritence from a common base class.
             * This means a call to a member method will cause a different implementation based on
             * the type of object that invokes the method.
             * Polymorphism allows a single method to have different implementations.
             * "virtual" keyword enables work with groups of related objects in a uniform way
             * 
             */
            Shape c = new Circle();
            c.Draw();
            Shape r = new Rectangle();
            r.Draw();
            Shape s = new Shape();
            s.Draw();

            /* Now let us learn about abstract classes
             * We use polymorphism to have different implementations for the same method. For this
             * we use virtual methods and override methods.
             * However, sometimes there is no need to have a separate base class with a virtual definition.
             * So we define an absract class, which holds abstract methods and variables
             * Abstract classes are defined only so that they can be the base class for other classes.
             * Thus we can inherit from those classes and then they can have their own Draw method defined.
             * Abstract class cannot be initiated
             * Abstract class may contain abstract methods and accessors
             * A non-abstract class must include actual implementation of inherited abstract methods and accessors.
             */

            /* Interfaces are completely abstract classes which can contain only methods, properties and no variables
             * Interfaces are essentially always public and always abstract so both those keywords are not used
             * names of Interfaces usually start with I
             * Also, we don't 'inherit' an interface, we merely 'implement' it
             * However, you "implement an interface" the same way in which you derive a class
             * However, override keyword is not needed if you use an interface
             */




        }
    }
    //Now let us try some nested classes.
    class Car
    {
        public string name;
        public Car(string name)
        {
            name = this.name;
            Motor m = new Motor("OHV V-8");
        }
        public class Motor
        {
            string motorName;
            public Motor(string motorName)
            {
                motorName = this.motorName;
            }
        }
    }
}
